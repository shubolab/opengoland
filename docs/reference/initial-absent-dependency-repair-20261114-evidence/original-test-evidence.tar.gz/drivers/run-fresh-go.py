import datetime,hashlib,json,os,subprocess
from pathlib import Path
root=Path('/Users/wangshubo/develop/openidea-go')
base=root/'.tools/continuation-20261114/initial-missing-repair/fresh-go-race'
base.mkdir(exist_ok=False)
builder=root/'.tools/go-tools-cache/sdks/go1.27.3/darwin-arm64/go'
env=os.environ.copy();env.pop('GOWORK',None)
env.update({'GOROOT':str(builder),'PATH':str(builder/'bin')+':/usr/bin:/bin:/usr/sbin:/sbin','GOENV':'off','GOTOOLCHAIN':'local','GOCACHE':str(root/'.tools/go-tools-cache/build-cache'),'GOMODCACHE':str(root/'.tools/go-tools-cache/modules'),'GOTELEMETRY':'off'})
started=datetime.datetime.now(datetime.UTC).isoformat()
cmd=[str(builder/'bin/go'),'test','-race','-count=1','-json','./...']
with(base/'go-race.jsonl').open('wb')as out,(base/'go-race.stderr').open('wb')as err:
 result=subprocess.run(cmd,cwd=root/'engine',env=env,stdout=out,stderr=err)
events=[json.loads(s)for s in(base/'go-race.jsonl').read_text().splitlines()]
summary={'startedAtUtc':started,'endedAtUtc':datetime.datetime.now(datetime.UTC).isoformat(),'command':cmd,'GOWORKAbsent':True,'exitCode':result.returncode,'testPasses':sum(e.get('Action')=='pass'and'Test'in e for e in events),'testSkips':sum(e.get('Action')=='skip'and'Test'in e for e in events),'failures':[e for e in events if e.get('Action')=='fail'],'packages':[{k:e[k]for k in('Package','Action')if k in e}for e in events if e.get('Action')in('pass','skip','fail')and'Test'not in e]}
with(base/'go-vet.log').open('wb')as log:vet=subprocess.run([str(builder/'bin/go'),'vet','./...'],cwd=root/'engine',env=env,stdout=log,stderr=subprocess.STDOUT)
summary['vetExitCode']=vet.returncode
summary['fileSha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in base.iterdir()if p.is_file()}
(base/'result.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))

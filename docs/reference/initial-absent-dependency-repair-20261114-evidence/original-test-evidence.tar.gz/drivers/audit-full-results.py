import hashlib,json,shutil,tarfile,xml.etree.ElementTree as ET
from pathlib import Path
root=Path('/Users/wangshubo/develop/openidea-go')
b=root/'.tools/continuation-20261114/initial-missing-repair/full-regression'
p=b/'result.json';original=b/'driver-result.original.json'
assert not original.exists();shutil.copyfile(p,original)
r=json.loads(original.read_text());assert r['testTaskExecuted'] and r['sourceStableDuringRun']
suites={};identities=set()
for q in sorted(b.glob('TEST-*.xml')):
 t=ET.fromstring(q.read_bytes());name=t.get('name');assert name not in suites
 suites[name]={k:int(t.get(k,'0'))for k in('tests','failures','errors','skipped')}
 for case in t.findall('testcase'):identities.add((case.get('classname'),case.get('name')))
assert len(suites)>170
old=set()
with tarfile.open(root/'.tools/continuation-20261114/root-recreation/candidate9-build/test-results.tar.gz')as archive:
 for member in archive.getmembers():
  if member.isfile()and member.name.endswith('.xml'):
   t=ET.fromstring(archive.extractfile(member).read())
   for case in t.findall('testcase'):old.add((case.get('classname'),case.get('name')))
r['xml']=suites;r['totals']={k:sum(s[k]for s in suites.values())for k in('tests','failures','errors','skipped')}
r['reportCount']=len(suites);r['previousC9TestIdentities']=len(old);r['removedPreviousTestIdentities']=[list(x)for x in sorted(old-identities)];r['addedTestIdentities']=[list(x)for x in sorted(identities-old)]
r['driverAggregationCorrection']={'originalSha256':hashlib.sha256(original.read_bytes()).hexdigest(),'reason':'Wildcard selected all classes and copied all fresh XML; initial summary used the wildcard as one repeated map key. Reparsed each original suite name without rerunning or modifying tests.'}
assert not r['removedPreviousTestIdentities']
p.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k]for k in('exitCode','sourceStableDuringRun','reportCount','totals','previousC9TestIdentities','removedPreviousTestIdentities')},indent=2))

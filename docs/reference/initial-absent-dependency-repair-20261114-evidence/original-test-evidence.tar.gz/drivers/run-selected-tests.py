#!/usr/bin/env python3
import datetime, hashlib, json, os, re, shutil, subprocess, sys
from pathlib import Path
import xml.etree.ElementTree as ET
ROOT=Path('/Users/wangshubo/develop/openidea-go')
PY=Path('/Users/wangshubo/.local/share/uv/python/cpython-3.13.11-macos-aarch64-none/bin/python3')
label,*classes=sys.argv[1:]
assert re.fullmatch(r'[a-z0-9-]+',label) and classes
out=ROOT/'.tools/continuation-20261114/initial-missing-repair'/label
out.mkdir(parents=True,exist_ok=False)
builder=ROOT/'.tools/go-tools-cache/sdks/go1.27.3/darwin-arm64/go'
runtime=ROOT/'.tools/release-tools/darwin-arm64/go'
sdk=ROOT/'.tools/platform/idea-2026.1.4/IntelliJ IDEA.app'
env=os.environ.copy();env.pop('GOWORK',None)
env.update({'JAVA_HOME':str(sdk/'Contents/jbr/Contents/Home'),'GOROOT':str(builder),
 'PATH':str(PY.parent)+':'+str(builder/'bin')+':/usr/bin:/bin:/usr/sbin:/sbin',
 'GOENV':'off','GOTOOLCHAIN':'local','GOCACHE':str(ROOT/'.tools/go-tools-cache/build-cache'),
 'GOMODCACHE':str(ROOT/'.tools/go-tools-cache/modules'),'OPENGOLAND_GO_TEST':str(runtime/'bin/go'),
 'OPENGOLAND_GOPLS_TEST':str(ROOT/'.tools/release-tools/darwin-arm64/bin/gopls'),'GOTELEMETRY':'off'})
capture=[str(PY),'scripts/build_inputs.py','capture']
subprocess.run(capture+[str(out/'source-before.json')],cwd=ROOT,env=env,check=True,capture_output=True)
cmd=['./gradlew','--no-daemon','--offline','-PplatformPath='+str(sdk),'-PgoBuilder='+str(builder/'bin/go'),'test']
for name in classes:cmd+=['--tests',name]
start=datetime.datetime.now(datetime.UTC)
(out/'command.json').write_text(json.dumps({'startedAtUtc':start.isoformat(),'command':cmd,'classes':classes,'GOWORKAbsent':True},indent=2)+'\n')
with(out/'gradle.log').open('wb')as log:result=subprocess.run(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
subprocess.run(capture+[str(out/'source-after.json')],cwd=ROOT,env=env,check=True,capture_output=True)
stable=json.loads((out/'source-before.json').read_text())==json.loads((out/'source-after.json').read_text())
log=(out/'gradle.log').read_text(errors='replace')
executed=bool(re.search(r'^> Task :test(?: FAILED)?\s*$',log,re.M))
stats={}
if executed:
 for name in classes:
  matches=list((ROOT/'build/test-results/test').glob('TEST-'+name+'.xml'))
  for path in matches:
   assert path.stat().st_mtime>=start.timestamp(), 'Refuse stale XML from earlier task'
   shutil.copyfile(path,out/path.name);node=ET.fromstring(path.read_bytes())
   stats[name]={k:int(node.get(k,'0'))for k in ('tests','failures','errors','skipped')}
report={'endedAtUtc':datetime.datetime.now(datetime.UTC).isoformat(),'exitCode':result.returncode,
 'sourceStableDuringRun':stable,'testTaskExecuted':executed,'xml':stats,
 'logSha256':hashlib.sha256((out/'gradle.log').read_bytes()).hexdigest()}
(out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))

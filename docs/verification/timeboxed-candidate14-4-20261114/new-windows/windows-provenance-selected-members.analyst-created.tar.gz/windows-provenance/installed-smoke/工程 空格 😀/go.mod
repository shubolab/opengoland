module example.org/installedsmoke

go 1.26.0

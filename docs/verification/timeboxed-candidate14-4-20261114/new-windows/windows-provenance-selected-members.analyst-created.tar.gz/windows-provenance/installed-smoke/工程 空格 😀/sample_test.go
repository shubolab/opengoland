package installedsmoke
import "testing"
func TestBundledInstalledRuntime(t *testing.T) { if "前😀" == "" {t.Fatal("Unicode")} }
